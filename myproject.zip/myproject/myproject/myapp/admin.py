from django.contrib import admin
from .models import FormData

admin.site.register(FormData)
